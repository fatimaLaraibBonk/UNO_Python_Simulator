from flask import Flask, jsonify, request, send_from_directory
import random, os

app = Flask(__name__, static_folder='static')

# -*- coding: utf-8 -*-
# Player 1 -> Minimax -> Defensive
# Player 2 -> Expectimax -> Offensive
# Player 3 -> USER/AI -> manual/ai

#card class
class Card:
  def __init__(self, color, number):
    self.card_color=color
    self.card_number=number
    self.card=(color, number)
  def __eq__(self, other):
    if other is None:
      return False
    return (self.card_color == other.card_color or
            self.card_number == other.card_number)
  #for nicer prints
  def __str__(self):
        return f"{self.card_color} {self.card_number}"
  def __repr__(self):
        return f"{self.card_color} {self.card_number}"
  def exact_match(self, other):
        return self.card_color == other.card_color and self.card_number == other.card_number
  def to_dict(self):
        return {"color": self.card_color, "number": self.card_number}

#deck generator
colors=["Red", "Blue", "Green", "Yellow"]
values=["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "Skip"]
def shuffle_deck(deck):
  for color in colors:
    for value in values:
      deck.append(Card(color, value))
  random.shuffle(deck)
  return deck

#Valid move check
def get_valid_moves(hand, top_card):
  #legal move generator
  valid_moves=[]
  #we go through the deck and throw in anything with the same color or number into valid moves
  for card in hand:
    if card==top_card:
      valid_moves.append(card)
  return valid_moves

#evaluation function
#different for offensive and defensive
#FOR P2
def evaluaiton_function_offenive(num_cards, avg_opponent, skip_in_hand):
  score=50-10*(num_cards)+1*(avg_opponent)+1*(skip_in_hand)
  return score
#FOR P1
def evaluation_function_defensive(num_cards, avg_opponent, skip_in_hand):
  score=50-5*(num_cards)+5*(avg_opponent)+4*(skip_in_hand)
  return score
#FOR P3
#p3 being defensive is performing poorly
#tunning it to be more aggreessive
def evaluation_function(num_cards, avg_opponent, skip_in_hand):
  score=50-8*(num_cards)+2*(avg_opponent)+2*(skip_in_hand)
  return score

def count_skips(hand):
  count=0
  for card in hand:
    if card.card_number=="Skip":
      count+=1
  return count

#state transition
def apply_move(state, move, current_player):
  #updating the state idk why we need to keep a state when i can just keep variables </3
  #move is the new caard
  #state is the old past
  #currrent player is jsut to show whos plaaayer rn
  new_state = {
      "Player1_hand": state["Player1_hand"].copy(),
      "Player2_hand": state["Player2_hand"].copy(),
      "Player3_hand": state["Player3_hand"].copy(),
      "Deck": state["Deck"].copy(),
      "Top_card": state["Top_card"],  # will update below
  }
  if current_player == 3:
      new_state["Player3_hand"].remove(move)
  elif current_player == 1:
      new_state["Player1_hand"].remove(move)
  else:
      new_state["Player2_hand"].remove(move)
  new_state["Top_card"] = move
  return new_state

#movement code
def pick_best_move_for_player1(player1_hand, player2_hand, player3_hand, deck, depth, valid_moves, top_card):
  state = {
      "Player1_hand": player1_hand.copy(),
      "Player2_hand": player2_hand.copy(),
      "Player3_hand": player3_hand.copy(),
      "Deck": deck.copy(),
      "Top_card": top_card
  }
  best_score = float('inf')
  best_move = "Dookie"
  for move in valid_moves:
    #current player 1
    #we applyy the current move and see how well they do and get their scores
    #and since this is min we do min value
    new_state = apply_move(state, move, 1)
    score = minmax_search(new_state, depth - 1, 2, [])
    if score < best_score:
      best_score = score
      best_move = move
  return best_move

def pick_best_move_for_player3(player1_hand, player2_hand, player3_hand, deck, depth, valid_moves, user_choice, top_card):
  #here we wwillcheck if its the user playing or the AI playinh
  #need to fix this part where player selects a card
  if user_choice == 1:
      # manual mode handled by /play_card endpoint
      return None
  else:
      #ai mode
      state = {
        "Player1_hand": player1_hand.copy(),
        "Player2_hand": player2_hand.copy(),
        "Player3_hand": player3_hand.copy(),
        "Deck": deck.copy(),
        "Top_card": top_card
      }
      best_score = float('-inf')
      best_move = "Dookie"
      for move in valid_moves:
        #current player 3
        #we applyy the current move and see how well they do and get their scores
        #and since this is max we do max value
        new_state = apply_move(state, move, 3)
        score = minmax_search_p3(new_state, depth - 1, 1, [])
        if score > best_score:
          best_score = score
          best_move = move
      return best_move

def pick_best_move_for_player2(player1_hand, player2_hand, player3_hand, deck, depth, valid_moves, top_card):
  state = {
      "Player1_hand": player1_hand.copy(),
      "Player2_hand": player2_hand.copy(),
      "Player3_hand": player3_hand.copy(),
      "Deck": deck.copy(),
      "Top_card": top_card
  }
  best_score=float('inf')
  best_move=None
  for move in valid_moves:
    new_state=apply_move(state, move, 2)
    score=expectimax_search(new_state, depth-1, 3, [], 0)
    if best_move is None or score < best_score:
      best_score = score
      best_move = move
  return best_move

#expectimax search
#usedBY P2 P2 IS OFFESIVE
def expectimax_search(state, depth, current_player, valid_moves, indent=0):
  #P1-RANDOM
  #P2->CHANCE
  #P3->MAX
  if current_player==1:
    hand=state["Player1_hand"]
  elif current_player==2:
    hand=state["Player2_hand"]
  else:
    hand=state["Player3_hand"]
  top_card=state["Top_card"]
  valid_moves=get_valid_moves(hand, top_card)
  prefix="|  "*indent
  #base case
  #SCORING IS ALWAYS FROM THE PERSPECTIVE OF MAX
  if depth==0:
    skips=count_skips(state["Player3_hand"])
    avg=(len(state["Player2_hand"])+len(state["Player1_hand"]))/2
    score=evaluation_function(len(state["Player3_hand"]), avg , skips)
    return score
  else:
    #agaim player 1 and 2 are opponents so they are min
    #and plsyer 3 is us so we are maxxing AURAMAXXING
    if current_player==3:
      max_value=-9999
      for move in valid_moves:
        new_state=apply_move(state, move, current_player)
        value=expectimax_search(new_state, depth-1, 1, [], indent+1)
        max_value=max(max_value, value)
      return max_value
    elif current_player==2:
      valid_moves=get_valid_moves(state["Player2_hand"], top_card)
      if valid_moves:
        best=-9999
        for move in valid_moves:
          new_state=apply_move(state, move, 2)
          value=expectimax_search(new_state, depth-1, 3, [], indent+1)
          best=max(best, value)
        return best
      #treat draw card as chance node
      deck=state["Deck"]
      if not deck:
        #wwhat to do if deck is empty
        skips = count_skips(state["Player3_hand"])
        avg = (len(state["Player2_hand"]) + len(state["Player1_hand"])) / 2
        return evaluation_function(len(state["Player3_hand"]), avg, skips)
      else:
        #deck isnt empty
        total_value=0
        for card in deck:
          prob=1/len(deck)#each card in deck is equally likely to be drawn
          #making a copy of the staate
          new_state={k: v[:] if isinstance(v, list) else v for k, v in state.items()}
          new_state["Player2_hand"]=state["Player2_hand"]+[card]
          value=expectimax_search(new_state, depth-1, 3, [], indent+1)
          total_value+=prob*value
        return total_value
    else:
      #p3 here is supposed to be random
      if not valid_moves:
        skips = count_skips(state["Player3_hand"])
        avg = (len(state["Player2_hand"]) + len(state["Player1_hand"])) / 2
        return evaluation_function(len(state["Player3_hand"]), avg , skips)
      move=random.choice(valid_moves)
      new_state=apply_move(state, move, 1)
      return expectimax_search(new_state, depth-1, 2, [], indent+1)

#minmax search
#USED BY P1
#MORE DEFENSIVE
def minmax_search(state, depth, current_player, valid_moves, indent=0):
  #P3-> MAX
  #P1->MIN
  #P2->MIN
  if current_player==1:
    hand=state["Player1_hand"]
  elif current_player==2:
    hand=state["Player2_hand"]
  else:
    hand=state["Player3_hand"]
  top_card=state["Top_card"]
  valid_moves=get_valid_moves(hand, top_card)
  #base case
  if depth==0:
    skips=count_skips(state["Player3_hand"])
    avg=(len(state["Player2_hand"])+len(state["Player1_hand"]))/2
    score=evaluation_function_defensive(len(state["Player3_hand"]), avg , skips)
    return score
  else:
    if current_player==3:
      #this is the max node
      max_value=-9999
      for move in valid_moves:
        new_state=apply_move(state, move, current_player)
        value=minmax_search(new_state, depth-1, 1, [], indent+1)
        max_value=max(max_value, value)
      return max_value
    #APPLYING MIN FOR BOTH P2 AND P1
    elif current_player==2:
      min_value=9999
      for move in valid_moves:
        new_state=apply_move(state, move, current_player)
        value=minmax_search(new_state, depth-1, 3, [], indent+1)
        min_value=min(min_value, value)
      return min_value
    else:
      #also min node
      min_value=9999
      for move in valid_moves:
        new_state=apply_move(state, move, current_player)
        value=minmax_search(new_state, depth-1, 2, [], indent+1)
        min_value=min(min_value, value)
      return min_value
  pass

#trying different strategies for p3
#minmax search for P3 - uses evaluation_function (more aggressive)
def minmax_search_p3(state, depth, current_player, valid_moves, indent=0):
  #P3-> MAX
  #P1->MIN
  #P2->MIN
  if current_player==1:
    hand=state["Player1_hand"]
  elif current_player==2:
    hand=state["Player2_hand"]
  else:
    hand=state["Player3_hand"]
  top_card=state["Top_card"]
  valid_moves=get_valid_moves(hand, top_card)
  #base case
  if depth==0:
    skips=count_skips(state["Player3_hand"])
    avg=(len(state["Player2_hand"])+len(state["Player1_hand"]))/2
    score=evaluation_function(len(state["Player3_hand"]), avg , skips)
    return score
  else:
    if current_player==3:
      #this is the max node
      max_value=-9999
      for move in valid_moves:
        new_state=apply_move(state, move, current_player)
        value=minmax_search_p3(new_state, depth-1, 1, [], indent+1)
        max_value=max(max_value, value)
      return max_value
    elif current_player==2:
      min_value=9999
      for move in valid_moves:
        new_state=apply_move(state, move, current_player)
        value=minmax_search_p3(new_state, depth-1, 3, [], indent+1)
        min_value=min(min_value, value)
      return min_value
    else:
      #also min node
      min_value=9999
      for move in valid_moves:
        new_state=apply_move(state, move, current_player)
        value=minmax_search_p3(new_state, depth-1, 2, [], indent+1)
        min_value=min(min_value, value)
      return min_value
  pass

#hand empty?
def deck_empty(deck):
  if not deck:
    return True
  else:
    return False

#giving starting cards to each player
def distribute_cards(player1_deck, player2_deck, player3_deck, deck):
  #each player gets 7 cards
  for i in range(7):
    player1_deck.append(deck[0])
    deck.pop(0)
    player2_deck.append(deck[0])
    deck.pop(0)
    player3_deck.append(deck[0])
    deck.pop(0)
  return player1_deck, player2_deck, player3_deck, deck

# ────────────────────────────────────────────────
# game state stored here between requests
# ────────────────────────────────────────────────
game = {}

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/start', methods=['POST'])
def start():
    data = request.json
    user_choice = data.get('user_choice', 2)  # 1=manual, 2=ai

    deck = []
    deck = shuffle_deck(deck)
    player1_hand, player2_hand, player3_hand, deck = distribute_cards([], [], [], deck)

    game.clear()
    game['player1_hand'] = player1_hand
    game['player2_hand'] = player2_hand
    game['player3_hand'] = player3_hand
    game['deck'] = deck
    game['cards_played'] = []
    game['skip_next_player'] = None
    game['players_won'] = []
    game['user_choice'] = user_choice
    game['current_player'] = 1
    game['waiting_for_human'] = False
    game['game_over'] = False

    return jsonify({
        "p1_count": len(player1_hand),
        "p2_count": len(player2_hand),
        "p3_hand": [c.to_dict() for c in player3_hand],
        "deck_count": len(deck),
        "top_card": None
    })

@app.route('/step', methods=['POST'])
def step():
    """Advance one player's turn — ditto of play_game loop logic"""
    if not game:
        return jsonify({"error": "no game"}), 400
    if game.get('game_over'):
        return jsonify({"game_over": True, "players_won": game['players_won']})

    player1_hand = game['player1_hand']
    player2_hand = game['player2_hand']
    player3_hand = game['player3_hand']
    deck = game['deck']
    cards_played = game['cards_played']
    skip_next_player = game['skip_next_player']
    players_won = game['players_won']
    user_choice = game['user_choice']
    cp = game['current_player']

    # dead game check
    if cards_played and not deck and not get_valid_moves(player1_hand, cards_played[-1]) and not get_valid_moves(player2_hand, cards_played[-1]) and not get_valid_moves(player3_hand, cards_played[-1]):
        game['game_over'] = True
        return jsonify({"game_over": True, "players_won": players_won, "message": "Deck empty and no valid moves. Game over."})

    if len(players_won) == 2:
        game['game_over'] = True
        return jsonify({"game_over": True, "players_won": players_won})

    event = {"player": cp, "action": None, "card": None, "message": ""}

    # ── PLAYER 1 ──
    if cp == 1:
        if deck_empty(player1_hand):
            if "Player1" not in players_won:
                players_won.append("Player1")
            event["action"] = "won"
            event["message"] = "Player 1 won!"
        elif skip_next_player == 1:
            event["action"] = "skipped"
            event["message"] = "Skipping player 1's turn"
            game['skip_next_player'] = None
        else:
            if not cards_played:
                event["message"] = "No cards placed down right now."
                valid_moves = player1_hand
                card_played = pick_best_move_for_player1(player1_hand, player2_hand, player3_hand, deck, 3, valid_moves, None)
                player1_hand.remove(card_played)
                cards_played.append(card_played)
                event["action"] = "played"
                event["card"] = card_played.to_dict()
                event["message"] = f"Player 1 played: {card_played}"
                if card_played.card_number == "Skip":
                    game['skip_next_player'] = 2
            else:
                top_card = cards_played[-1]
                valid_moves = get_valid_moves(player1_hand, top_card)
                if not valid_moves:
                    if deck:
                        card_drawn = deck[0]
                        player1_hand.append(deck[0])
                        deck.pop(0)
                        event["action"] = "drew"
                        event["card"] = card_drawn.to_dict()
                        event["message"] = f"Player 1 drawed: {card_drawn}"
                    else:
                        event["action"] = "no_moves"
                        event["message"] = "Player 1 has no moves and deck is empty"
                else:
                    card_played = pick_best_move_for_player1(player1_hand, player2_hand, player3_hand, deck, 3, valid_moves, top_card)
                    player1_hand.remove(card_played)
                    cards_played.append(card_played)
                    event["action"] = "played"
                    event["card"] = card_played.to_dict()
                    event["message"] = f"Player 1 played: {card_played}"
                    if card_played.card_number == "Skip":
                        game['skip_next_player'] = 2

    # ── PLAYER 2 ──
    elif cp == 2:
        if deck_empty(player2_hand):
            if "Player2" not in players_won:
                players_won.append("Player2")
            event["action"] = "won"
            event["message"] = "Player 2 won!"
        elif skip_next_player == 2:
            event["action"] = "skipped"
            event["message"] = "Skipping player 2's turn"
            game['skip_next_player'] = None
        else:
            top_card = cards_played[-1]
            valid_moves = get_valid_moves(player2_hand, top_card)
            if not valid_moves:
                if deck:
                    card_drawn = deck[0]
                    player2_hand.append(deck[0])
                    deck.pop(0)
                    event["action"] = "drew"
                    event["card"] = card_drawn.to_dict()
                    event["message"] = f"Player 2 drawed: {card_drawn}"
                else:
                    event["action"] = "no_moves"
                    event["message"] = "Player 2 has no moves and deck is empty"
            else:
                card_played = pick_best_move_for_player2(player1_hand, player2_hand, player3_hand, deck, 3, valid_moves, top_card)
                player2_hand.remove(card_played)
                cards_played.append(card_played)
                event["action"] = "played"
                event["card"] = card_played.to_dict()
                event["message"] = f"Player 2 played: {card_played}"
                if card_played.card_number == "Skip":
                    game['skip_next_player'] = 3

    # ── PLAYER 3 ──
    elif cp == 3:
        if deck_empty(player3_hand):
            if "Player3" not in players_won:
                players_won.append("Player3")
            event["action"] = "won"
            event["message"] = "Player 3 won!"
        elif skip_next_player == 3:
            event["action"] = "skipped"
            event["message"] = "Skipping player 3's turn"
            game['skip_next_player'] = None
        else:
            top_card = cards_played[-1]
            valid_moves = get_valid_moves(player3_hand, top_card)
            if not valid_moves:
                if deck:
                    card_drawn = deck[0]
                    player3_hand.append(deck[0])
                    deck.pop(0)
                    event["action"] = "drew"
                    event["card"] = card_drawn.to_dict()
                    event["message"] = f"Player 3 drawed: {card_drawn}"
                else:
                    event["action"] = "no_moves"
                    event["message"] = "Player 3 has no moves and deck is empty"
            elif user_choice == 1:
                # manual mode — wait for human input
                game['waiting_for_human'] = True
                return jsonify({
                    "waiting_for_human": True,
                    "valid_moves": [c.to_dict() for c in valid_moves],
                    "p3_hand": [c.to_dict() for c in player3_hand],
                    "top_card": cards_played[-1].to_dict()
                })
            else:
                card_played = pick_best_move_for_player3(player1_hand, player2_hand, player3_hand, deck, 3, valid_moves, user_choice, top_card)
                player3_hand.remove(card_played)
                cards_played.append(card_played)
                event["action"] = "played"
                event["card"] = card_played.to_dict()
                event["message"] = f"Player 3 played: {card_played}"
                if card_played.card_number == "Skip":
                    game['skip_next_player'] = 1

    # advance to next player
    game['current_player'] = (cp % 3) + 1

    if len(players_won) == 2:
        game['game_over'] = True

    return jsonify({
        "event": event,
        "top_card": cards_played[-1].to_dict() if cards_played else None,
        "p3_hand": [c.to_dict() for c in player3_hand],
        "p1_count": len(player1_hand),
        "p2_count": len(player2_hand),
        "deck_count": len(deck),
        "players_won": players_won,
        "game_over": game['game_over']
    })

@app.route('/play_card', methods=['POST'])
def play_card():
    """Human picks a card in manual mode"""
    data = request.json
    color = data['color']
    number = data['number']
    player3_hand = game['player3_hand']
    cards_played = game['cards_played']

    card_obj = Card(color, number)
    # find exact match in hand
    matched = next((c for c in player3_hand if c.exact_match(card_obj)), None)
    if not matched:
        return jsonify({"error": "Invalid card."}), 400

    player3_hand.remove(matched)
    cards_played.append(matched)
    if matched.card_number == "Skip":
        game['skip_next_player'] = 1
    game['waiting_for_human'] = False
    game['current_player'] = 1

    if deck_empty(player3_hand):
        if "Player3" not in game['players_won']:
            game['players_won'].append("Player3")

    return jsonify({
        "event": {"player": 3, "action": "played", "card": matched.to_dict(), "message": f"Player 3 played: {matched}"},
        "top_card": cards_played[-1].to_dict(),
        "p3_hand": [c.to_dict() for c in player3_hand],
        "p1_count": len(game['player1_hand']),
        "p2_count": len(game['player2_hand']),
        "deck_count": len(game['deck']),
        "players_won": game['players_won'],
        "game_over": len(game['players_won']) >= 2
    })

if __name__ == '__main__':
    os.makedirs('static', exist_ok=True)
    app.run(debug=True, port=5000)
